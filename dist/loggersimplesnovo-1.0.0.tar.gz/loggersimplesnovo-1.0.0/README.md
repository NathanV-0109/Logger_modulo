# Logger Simplificado

**Logger Simplificado** é um logger de execução simples para
facilitar o codificação e previnir possiveis erros

## Funções

* `warning()` - Retorna um **warning** no local inserido
 

* `information(text)` - Recebe uma string e retorna uma **information** no local inserido
 

* `error(text)` - Recebe uma string e retorna uma **error** no local inserido
 

* `debug(text)` - Recebe uma string e retorna uma **debug** no local inserido
 

* `critical(text)` - Recebe uma string e retorna uma **critical** no local inserido
 