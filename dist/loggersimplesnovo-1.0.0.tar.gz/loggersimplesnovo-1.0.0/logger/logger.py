
def warning():
  print("Warning")

def information(text):
  print("Information: " + text)

def error(text):
  print("Error: " + text)

def debug(text):
  print("Debug: " + text)

def critical(text):
  print("Critical: " + text)



